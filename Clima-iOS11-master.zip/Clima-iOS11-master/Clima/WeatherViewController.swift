//
//  ViewController.swift
//  WeatherApp
//
//  Created by Angela Yu on 23/08/2015.
//  Copyright (c) 2015 London App Brewery. All rights reserved.
//

import UIKit
import CoreLocation
import SwiftyJSON
import Alamofire

class WeatherViewController: UIViewController , CLLocationManagerDelegate , changeCityDelegte{
    
    //Constants
    let WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather"
    let APP_ID = "e72ca729af228beabd5d20e3b7749713"
    var locationManager = CLLocationManager()
    

    //TODO: Declare instance variables here
    var weatherDataModel = WeatherDataModel()
    
    //Pre-linked IBOutlets
    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        //TODO:Set up the location manager here.
    
        
        
    }
    
    
    
    //MARK: - Networking
    /***************************************************************/
    
    //Write the getWeatherData method here:
    func getWeatherData(url :String , paramters : [String : String ]){//here i made the request with the respons method
//        request
        request(url, method: .get, parameters: paramters).responseJSON {//when success the next part is formating the data we get bakc from the weather open weather map and procssign it so we can display it on the screen
            response in
            if response.result.isSuccess {
                let weatherJSON : JSON = JSON(response.result.value!)//here we got the data back form the web service of the type JSON.and we need to unwrap it because it's of type optional and we need to convert it to a type of JSON cause it's default type is Any.لما اجي اطبع قيمه الويزر جيسون هلاقيها اطبعت كذا مره وده لالوكشن مانجر بتاخد وقت عشات كدا ممكن اشيل الكلاس بتاعي م الديليجيت ن عمليه وقف ال
                self.updateWeatherData(json : weatherJSON)//formationg for the data which get back from the service..don't foget to put a self before the meathod name cause we are in closure
               // let tempreture = weatherJSON["main"]["tempreture"]//now the first thing we want to grab from our data is the tempreture//now the first thing we want to grab from our data is the tempreture
                self.updateUIWithWeatherData()
                
            } else {
                self.cityLabel.text = "connection error"
            }
        }
//        Alamofire.request(url , method : .get , paramters: paramters).responsJSON{
//            response in
//                if resopnse.result.isSuccess{/
//                    let weatherJSON : JSON = JSON(response.result.value!) /
//                    self.updateWeatherData(json: weatherJSON)
//                    let tempreture = json["main"]["tempreture"]
//                    updateUIWithWeatherData()
//
//                }
//                else{
//                    self.cityLabel.text = " conection error"
//                }
//
//        }
        
    }

    
    
    
    
    
    //MARK: - JSON Parsing
    /***************************************************************/
   
    
    //Write the updateWeatherData method here:
    func updateWeatherData(json : JSON){
        let tempResult = json["main"]["temp"].double
        weatherDataModel.temperature = tempResult! - 273.14 //to convert it into celecius
        weatherDataModel.city = (json["name"]).stringValue
        weatherDataModel.condition = json["weather"][0]["id"].intValue
        weatherDataModel.weatherIconName = weatherDataModel.updateWeatherIcon(condition: weatherDataModel.condition)
        
        
    }

    
    
    
    //MARK: - UI Updates
    /***************************************************************/
    
    
    //Write the updateUIWithWeatherData method here:
    
    func updateUIWithWeatherData(){
        cityLabel.text = weatherDataModel.city
        temperatureLabel.text = "\(weatherDataModel.temperature)"
        weatherIcon.image = UIImage(named : weatherDataModel.weatherIconName)
    }
    
    
    
    
    //MARK: - Location Manager Delegate Methods
    /***************************************************************/
    
    
    //Write the didUpdateLocations method here:
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations[locations.count - 1] //اخرقيمه بتكون اكر دقه
        if location.horizontalAccuracy > 0{//هتاكد الاول ان الاحداثيات صح
            locationManager.stopUpdatingLocation() //عشان مستهلكش من البطاريه والشغل
            locationManager.delegate = nil
            // هيدينيايرور عشان انا مش مشغل اللوكيشن ع السيميوليتر هروح ديباج ومن هناك هختارلوكيشن وهححد اللوكيشن بتاع ابل
          //بعد كدا هستخدم الاحداثيات دي كبرامتر لل اي بي اي اللي هستخمه
            let longitude = String(location.coordinate.longitude)
            let latitude = String(location.coordinate.latitude)
            var params : [String : String] = ["lat" : latitude , "lon" : longitude , "appid" : APP_ID]
            getWeatherData(url: WEATHER_URL, paramters: params)//بعد ما جبت الاحداثيات هعمل طلب للسيرفر بالبرامترز بتاعته عن طريق استدعاء الميود دي اللي فيها الشغل بتاع النتورك
            
        }
    }
    
    //Write the didFailWithError method here:
    
    

    
    //MARK: - Change City Delegate methods
    /***************************************************************/
    
    
    //Write the userEnteredANewCityName Delegate method here:
    func userInteredNewCityName(city: String) {
        let params : [String : String] = ["q" : "city","appid" : APP_ID]
        getWeatherData(url: WEATHER_URL, paramters: params)
    }

    
    //Write the PrepareForSegue Method here
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "changeCityName"{
            let destinationVC = segue.destination as! ChangeCityViewController
            destinationVC.delegate = self
        }
    }
    
    
    
    
    
}


