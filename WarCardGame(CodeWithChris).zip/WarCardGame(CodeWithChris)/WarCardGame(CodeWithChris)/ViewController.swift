//
//  ViewController.swift
//  WarCardGame(CodeWithChris)
//
//  Created by Omar Elsaeed on 7/28/19.
//  Copyright © 2019 Omar Elsaeed. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var cpuCard: UIImageView!
    @IBOutlet weak var playerCard: UIImageView!
    @IBOutlet weak var playerScore: UILabel!
    @IBOutlet weak var cpuScore: UILabel!
    
    let cardsData = ["card1","card2","card3","card4","card5","card6","card7","card8","card9","card10","card11","card12","card13","card14"]
    var playerScoreLabel = 0
    var cpuScoreLabel = 0
    var cpuRandomNum = 0
    var playerRandomNum = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateCardsImages()
    }

    func updateCardsImages(){
        cpuRandomNum = Int(arc4random_uniform(13))
        cpuCard.image = UIImage(named : cardsData[cpuRandomNum] )
        playerRandomNum = Int(arc4random_uniform(13))
        playerCard.image = UIImage(named : cardsData[playerRandomNum] )
    }

   
    @IBAction func didDealButtonPressed(_ sender: Any) {
        updateCardsImages()
        if cpuRandomNum > playerRandomNum {
            cpuScoreLabel += 1
            cpuScore.text = "\(cpuScoreLabel)"
        }
        else {
            playerScoreLabel += 1
            playerScore.text = "\(playerScoreLabel)"
        }
    }
    
}

