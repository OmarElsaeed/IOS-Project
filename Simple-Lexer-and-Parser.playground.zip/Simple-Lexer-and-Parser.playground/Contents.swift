//: Playground - noun: a place where people can play

import UIKit

enum Token{
    case num(Int)
    case plus
    case minus
}

class Lexer{
    enum Error : Swift.Error{
        case invalidCharacter(Character)
    }
    let input: String.CharacterView
    var position: String.CharacterView.Index
    
    init(input: String){
        self.input = input.characters
        self.position = input.startIndex
    }
    func lex()throws -> [Token] {
        var tokens = [Token]()
        while let nextCharacter = peek(){
            switch nextCharacter{
            case "0"..."9" :
                let value = getNumber()
                tokens.append(.num(value))
            case "+" :
                tokens.append(.plus)
                advance()
            case "-" :
                tokens.append(.minus)
                advance()
            case " " :
                advance()
            default :
                throw Lexer.Error.invalidCharacter(nextCharacter)
            }
        }
        return tokens
    }
    func getNumber() -> Int{
        var value = 0
        while let nextCharater = peek(){
            switch nextCharater {
            case "0"..."9":
                value = value * 10 + Int(String(nextCharater))!
                advance()
            default:
                return value
            }
        }
         return value
    }
    func peek()->Character?{
        guard position < input.endIndex else {return nil}
        return input[position]
    }
    func advance(){
        assert(position < input.endIndex, "the position is greater than the endIndex")
        position = input.index(after: position)
    }
    
}


class Parser{
    enum Error: Swift.Error{
        case invalidToken(Token)
        case unexpectedEndOfInput
    }
    let tokens:[Token]
    var position = 0
    
    init(tokens:[Token]){
        self.tokens = tokens
    }
    
    func parse()throws ->Int{
        var value = try getNumber()
        while let token = getNextToken(){
            switch token{
            case .plus:
                let nextNumber = try getNumber()
                value += nextNumber
            case .minus:
                let nextNumber = try getNumber()
                value -= nextNumber
            case .num:
                throw Parser.Error.invalidToken(token)
            }
        }
        return value
    }
    
    func getNextToken()->Token?{
        guard position < tokens.count else {return nil}
        let token = tokens[position]
        position += 1
        return token
    }
    func getNumber()throws ->Int{
        guard let token = getNextToken() else {throw Parser.Error.unexpectedEndOfInput}
        switch token{
        case .num(let value):
            return value
        case .plus:
            throw Parser.Error.invalidToken(token)
        case .minus:
            throw Parser.Error.invalidToken(token)
        }
    }
}
func evaluate(_ input: String){
    print("Evaluating \(input)")
    do{
        let lexer = Lexer(input: input)
        let tokens = try lexer.lex()
        print("Lexer output :  \(tokens) ")
        
        //let parser = Parser(tokens: tokens)
        let parser = Parser(tokens: tokens)
        let result = try parser.parse()
        print("Parser Output is : \(result)")
    }catch Lexer.Error.invalidCharacter(let character){
        print("input contained an invalid character \(character)")
    }catch Parser.Error.invalidToken(let token){
        print("invalid toke during parsing \(token)")
    }catch Parser.Error.unexpectedEndOfInput{
        print("unexpected end of the Parsing")
    }
    catch{
        print("an error occured \(error)")
    }
    
}
evaluate("1 + 5 + 3 - 6")
